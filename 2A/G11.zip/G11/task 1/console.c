// Console input and output.
// Input is from the keyboard or serial port.
// Output is written to the screen and serial port.

#include "types.h"
#include "defs.h"
#include "param.h"
#include "traps.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "fs.h"
#include "file.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "x86.h"

static void consputc(int);

static int panicked = 0;

static struct {
  struct spinlock lock;
  int locking;
} cons;

static int
printint(int xx, int base, int sign)
{
  static char digits[] = "0123456789abcdef";
  char buf[16];
  int i;
  uint x;

  if(sign && (sign = xx < 0))
    x = -xx;
  else
    x = xx;

  i = 0;
  do{
    buf[i++] = digits[x % base];
  }while((x /= base) != 0);

  if(sign)
    buf[i++] = '-';

  int ans = i;
  while(--i >= 0)
    consputc(buf[i]);
  return ans;
}
//PAGEBREAK: 50

// Print to the console. only understands %d, %x, %p, %s.
void
cprintf(char *fmt, ...)
{
  int i, c, locking;
  uint *argp;
  char *s;

  locking = cons.locking;
  if(locking)
    acquire(&cons.lock);

  if (fmt == 0)
    panic("null fmt");

  argp = (uint*)(void*)(&fmt + 1);
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
    if(c != '%'){
      consputc(c);
      continue;
    }
    c = fmt[++i] & 0xff;
    if(c == 0)
      break;
    switch(c){
    case 'd':
      printint(*argp++, 10, 1);
      break;
    case 'x':
    case 'p':
      printint(*argp++, 16, 0);
      break;
    case 's':
      if((s = (char*)*argp++) == 0)
        s = "(null)";
      for(; *s; s++)
        consputc(*s);
      break;
    case '%':
      consputc('%');
      break;
    default:
      // Print unknown % sequence to draw attention.
      consputc('%');
      consputc(c);
      break;
    }
  }

  if(locking)
    release(&cons.lock);
}

void
panic(char *s)
{
  int i;
  uint pcs[10];

  cli();
  cons.locking = 0;
  // use lapiccpunum so that we can call panic from mycpu()
  cprintf("lapicid %d: panic: ", lapicid());
  cprintf(s);
  cprintf("\n");
  getcallerpcs(&s, pcs);
  for(i=0; i<10; i++)
    cprintf(" %p", pcs[i]);
  panicked = 1; // freeze other CPU
  for(;;)
    ;
}

//PAGEBREAK: 50
#define BACKSPACE 0x100
#define CRTPORT 0x3d4
#define LEFT 228
#define RIGHT 229
#define UP 226
#define DOWN 227
static ushort *crt = (ushort*)P2V(0xb8000);  // CGA memory

static void
cgaputc(int c)
{
  int pos;

  // Cursor position: col + 80*row.
  outb(CRTPORT, 14);
  pos = inb(CRTPORT+1) << 8;
  outb(CRTPORT, 15);
  pos |= inb(CRTPORT+1);


  if(c == '\n')
    pos += 80 - pos%80;
  else if(c == BACKSPACE){
    if(pos > 0) --pos;
  }else if(c == LEFT){
    if(pos > 0) --pos;
  }else{
    crt[pos++] = (c&0xff) | 0x0700;  // black on white
  }

  if(pos < 0 || pos > 25*80)
    panic("pos under/overflow");

  if((pos/80) >= 24){  // Scroll up.
    memmove(crt, crt+80, sizeof(crt[0])*23*80);
    pos -= 80;
    memset(crt+pos, 0, sizeof(crt[0])*(24*80 - pos));
  }

  outb(CRTPORT, 14);
  outb(CRTPORT+1, pos>>8);
  outb(CRTPORT, 15);
  outb(CRTPORT+1, pos);
  if(c == BACKSPACE){
    crt[pos] = ' ' | 0x0700;
  }
}

void
consputc(int c)
{
  if(panicked){
    cli();
    for(;;)
      ;
  }

  if(c == BACKSPACE){
    uartputc('\b'); uartputc(' '); uartputc('\b');
  }else if(c == LEFT){
    uartputc('\b');
  }else{
    uartputc(c);
  }
  cgaputc(c);
}

// We have to add another variable to note the position of last letter. 
// Normally (without left and right cursor movements) this is basically input.e
// but as we can alter e when moving left or right we need one more vaiable to store the last index
#define INPUT_BUF 128
struct {
  char buf[INPUT_BUF];
  uint r;  // Read index
  uint w;  // Write index
  uint e;  // Edit index
  uint l;  // Last letter(of current command) index
} input;
char tmpbuf[INPUT_BUF];
char tmpchar;
#define C(x)  ((x)-'@')  // Control-x

/*

  History begins
  We implement history buffer using circular array logic same as we have done in input buffer
  * we are using tmpbuf for stroing the current command entered
*/

#define MAX_HISTORY 16

struct{
  char buf[MAX_HISTORY][INPUT_BUF]; // to store upto 16 past commands
  int l; // latest command used
  int s; // state of the history, contains the index if up arrow used, else -1
  int nos; // total slots filled in history
} historyBuf;

// utility function definitions
void leftShift(void);
void rightShift(void);

void saveToHistory(void);
void clearScreen(void);
void copyTypedToTmpbuf(void);
void fillInputBuffer(int index);
void fillScreenWithHistory(int index);

void consoleintr(int (*getc)(void))
{
  int c, doprocdump = 0;

  acquire(&cons.lock);
  while((c = getc()) >= 0){
    switch(c){
    case C('P'):  // Process listing.
      // procdump() locks cons.lock indirectly; invoke later
      doprocdump = 1;
      break;
    case C('U'):  // Kill line.
      while(input.e!=input.l){
        consputc(input.buf[input.e%INPUT_BUF]);
        input.e++;
      }
      while(input.e != input.w &&
            input.buf[(input.e-1) % INPUT_BUF] != '\n'){
        input.e--;
        input.l--;
        consputc(BACKSPACE);
      }
      break;
    // case C('E'):
    //   input.e+=printint(input.e, 10, 1);
    //   break;
    case C('H'): case '\x7f':  // Backspace
      if(input.l != input.e && input.e != input.w){
        consputc(LEFT);
        input.e--;
        input.l--;
        leftShift();
      }else if(input.e != input.w){
        input.e--;
        input.l--;
        consputc(BACKSPACE);
      }
      break;
    case LEFT:
      if(input.e != input.w){
        input.e--;
        consputc(LEFT);
      }
      break;
    case RIGHT:
      if(input.e != input.l){
        consputc(input.buf[(input.e)%INPUT_BUF]);
        // consputc(RIGHT);
        input.e++;
      }
      break;
    case UP:
      if(historyBuf.s < historyBuf.nos-1){
        clearScreen();
        if(historyBuf.s == -1){
          copyTypedToTmpbuf();
          // only for the time before accessing the history store the contents
          // of buffer in tmpbuf.
        }
        historyBuf.s++; // change the state by 1. to access the next command in the history.
        // index of history is relatively history.s from reference as history.l
        // history.l - history.s - 1
        input.l = input.r, input.e = input.r;
        int hisBufIndex = (MAX_HISTORY +  historyBuf.l - historyBuf.s - 1)%MAX_HISTORY;
        fillInputBuffer(hisBufIndex);
        fillScreenWithHistory(hisBufIndex);
      }// nothing to do elsewise
      break;
    case DOWN:
      if(historyBuf.s > 0){// when up arrow is multiple times
        clearScreen();
        historyBuf.s--; // to bring the previous state
        input.l = input.r, input.e = input.r;
        int hisBufIndex = (MAX_HISTORY + historyBuf.l - historyBuf.s -1)%MAX_HISTORY;
        fillInputBuffer(hisBufIndex);
        fillScreenWithHistory(hisBufIndex);
      }else if(historyBuf.s==0){
        // when up arrow is used once we want to bring back the command we typed
        clearScreen();
        historyBuf.s--;
        // bringing tmpbuf contents to input buffer and scree.
        input.l = input.r, input.e = input.r;
        uint len = 0;
        char c = tmpbuf[len];
        while(c!='\0'){
          input.buf[(input.r+len)%INPUT_BUF] = c;
          consputc(c);
          len++;
          c = tmpbuf[len];
          input.e++;
          input.l++;
        }
      }// nothing to do if state is -1 as up arrow is not used at all.
      break;
    default:
      if(c=='\n' || c=='\r'){
        input.e = input.l;
        saveToHistory();
      }
      if(c != 0 && input.e-input.r < INPUT_BUF){
        c = (c == '\r') ? '\n' : c;
        if(input.l > input.e){
          // if the inserted caracter is in the middle
          // the next to it string has to be moved a bit
          tmpchar = input.buf[input.e%INPUT_BUF];
          input.buf[input.e%INPUT_BUF] = c;
          consputc(c);
          rightShift();
        }else{
          input.buf[input.e% INPUT_BUF] = c;
          input.e++;
          input.l++;
          consputc(c);
        }
        if(c == '\n' || c == C('D') || input.l == input.r+INPUT_BUF){
          input.w = input.l;
          
          wakeup(&input.r);
        }
      }
      break;
    }
  }
  release(&cons.lock);
  if(doprocdump) {
    procdump();  // now call procdump() wo. cons.lock held
  }
}

// utility fucntions
void fillInputBuffer(int index){
  uint i = 0;
  char c = historyBuf.buf[index][i];
  while(c!='\0'){
    input.buf[(input.r+i)%INPUT_BUF] = c;
    i++;
    c = historyBuf.buf[index][i];
    input.e++;
    input.l++;
  }
}
void fillScreenWithHistory(int index){
  uint i = 0;
  char c = historyBuf.buf[index][i];
  while(c!='\0'){
    consputc(c);
    i++;
    c = historyBuf.buf[index][i];
  }
}
void copyTypedToTmpbuf(void){
  int j = 0;
  for(int i=input.r;i<input.l;i++,j++){
    tmpbuf[j] = input.buf[i%INPUT_BUF];
  }
  tmpbuf[j] = '\0';
}
void clearScreen(void){
  for(int i=input.l;i>input.r;i--){
    consputc(BACKSPACE);
  }
}
int allSpaces(void){
  uint i = 0;
  while(i + input.r < input.l){
    if(input.buf[(input.r + i)%INPUT_BUF] != ' ' && input.buf[(input.r + i)%INPUT_BUF] != '\t'){
      return 0;
    }
    i++;
  }
  return 1;
}

uint preStrip(void){
  uint i = 0;
  while(input.buf[(input.r + i)%INPUT_BUF] == ' ')i++;
  return i;
}
uint postStrip(void){
  uint i = 1;
  while(input.buf[(input.l - i)%INPUT_BUF] == ' ')i++;
  return i-1;
}
void saveToHistory(void){
  historyBuf.s = -1;
  if(allSpaces()){
    return;
  }
  if(historyBuf.nos<MAX_HISTORY){
    historyBuf.nos++;
  }
  uint i = 0;
  uint ending = postStrip();
  uint starting = preStrip();
  while(starting + i + input.r<input.l - ending){
    historyBuf.buf[historyBuf.l][i] = input.buf[(starting + input.r + i)%INPUT_BUF];
    i++;
  }
  historyBuf.buf[historyBuf.l][i] = '\0';
  historyBuf.l = (historyBuf.l+1)%MAX_HISTORY;
}
// echo hello world
void leftShift(void){
  int n = input.l - input.e;
  int i = 0;
  
  for(i=0;i<n;i++){
    char tmp = input.buf[(input.e+1+i)%INPUT_BUF];
    input.buf[(input.e+i)%INPUT_BUF] = tmp;
    consputc(tmp);
  }
  consputc(' ');
  for(i=0;i<=n;i++){
    consputc(LEFT);
  }
}
void rightShift(void){
  int n = input.l - input.e;
  int i;
  input.e++, input.l++;
  for(i=input.l-1;i>input.e;i--){
    input.buf[i%INPUT_BUF] = input.buf[(i-1)%INPUT_BUF];
  }
  input.buf[i%INPUT_BUF] = tmpchar;
  tmpchar = '\0';
  
  for(i = input.e;i<input.l;i++){
    consputc(input.buf[i%INPUT_BUF]);
  }
  for(i=0;i<n;i++){
    consputc(LEFT);
  }
}



int
consoleread(struct inode *ip, char *dst, int n)
{
  uint target;
  int c;

  iunlock(ip);
  target = n;
  acquire(&cons.lock);
  while(n > 0){
    while(input.r == input.w){
      if(myproc()->killed){
        release(&cons.lock);
        ilock(ip);
        return -1;
      }
      sleep(&input.r, &cons.lock);
    }
    c = input.buf[input.r++ % INPUT_BUF];
    if(c == C('D')){  // EOF
      if(n < target){
        // Save ^D for next time, to make sure
        // caller gets a 0-byte result.
        input.r--;
      }
      break;
    }
    *dst++ = c;
    --n;
    if(c == '\n')
      break;
  }
  release(&cons.lock);
  ilock(ip);

  return target - n;
}

/** u.functions end **/
int
consolewrite(struct inode *ip, char *buf, int n)
{
  int i;

  iunlock(ip);
  acquire(&cons.lock);
  for(i = 0; i < n; i++)
    consputc(buf[i] & 0xff);
  release(&cons.lock);
  ilock(ip);

  return n;
}

void
consoleinit(void)
{
  initlock(&cons.lock, "console");

  devsw[CONSOLE].write = consolewrite;
  devsw[CONSOLE].read = consoleread;
  cons.locking = 1;

  ioapicenable(IRQ_KBD, 0);
}
// int var = 0;
int history(char *buffer, int historyId){
	if(historyId < 0 || historyId >= MAX_HISTORY){
    return 2;
  }else if(historyId >= historyBuf.nos){
    // If 5 are there is the memory then id can be upto 4
    // historyId is indirectly history.s -> state
    return 1;
  }else{
    // if(var==0)
    // var = 1,cprintf("console\n");
    int index = (MAX_HISTORY + historyBuf.l - historyId -1)%MAX_HISTORY;
    uint i = 0;
    char c = historyBuf.buf[index][i];
    while(c!='\0'){
      buffer[i] = c;
      i++;
      c = historyBuf.buf[index][i];
    }
    buffer[i] = '\0';
    return 0;
  }
}
