#include "types.h"
#include "user.h"

int main()
{
	int retime,rutime,stime,n1;
    int k = 0;
	for (int a = 0; a < 5; a++)
	{
		n1 = fork();
        

        int pid = wait2(&retime, &rutime, &stime);
		if (!n1){
            k++; // k denote the number of ancestors
                 // of the current child process
			printf(1, "%d Child Process.\n", k);
			continue;
		}else if (pid == n1){
			if(n1<10){
                printf(1, "| PID:  %d ",n1);
            }else{
                printf(1, "| PID: %d ",n1);
            }
            if(retime< 10){
                printf(1, "| retime:  %d ", retime);
            }else{
                printf(1, "| retime: %d ", retime);
            }
            if(rutime< 10){
                printf(1, "| rutime:  %d ", rutime);
            }else{
                printf(1, "| rutime: %d ", rutime);
            }
            if(stime< 10){
                printf(1, "| stime:  %d ", stime);
            }else{
                printf(1, "| stime: %d ", stime);
            }
            printf(1, "|\n");
		}
        // print(pid, retime, rutime, stime);
        else{
			printf(1, "Not able to terminate the child process.\n");
		}
	}
	exit();
}