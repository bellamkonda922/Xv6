#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc,char* argv[])
{
    int n = atoi(argv[1]);
    int storeready[3], storerun[3], storesleep[3];
    int t = 0;
    for(int h = 0; h < 3 * n; h++) {
        int pid1 = fork();
        if (pid1 == 0) {
			#ifdef SML
			int i = (getpid()) % 3 + 1;
			set_prio(i);
            for (int j = 0; j < 100; j++) {
				for (int k = 0; k < 1000000; k++) {
					t += j * (k % 9);
					t = t % 1009;
				}
			}
            #endif
            printf(1, "", t%2);
            exit();
        }
        continue;
    }
	for(int i = 0; i < 3 * n; ++i) { 
		int retime, rutime, stime, ctime, priority;
		int pid = wait4(&ctime, &retime, &rutime, &stime, &priority);
		if(pid % 3 == 0) {
			storeready[0] += retime;
			storerun[0] += rutime;
			storesleep[0] += stime;
		} else if (pid % 3 == 1) {
			storeready[1] += retime;
			storerun[1] += rutime;
			storesleep[1] += stime;
		} else {
			storeready[2] += retime;
			storerun[2] += rutime;
			storesleep[2] += stime;
		}
		int turnaroundtime = ctime + retime + rutime + stime;
		printf(1, "pid: %d, ctime: %d, retime: %d , rutime: %d , stime: %d, Turnaround: %d ,priority: %d \n", pid, ctime, retime, rutime, stime, turnaroundtime, priority);
	}
    int turnaverage[3];
    for(int i = 0; i < 3; i++) {
        turnaverage[i] = (storeready[i] + storerun[i] + storesleep[i]) / n;
        storeready[i] /= n;
        storerun[i] /= n;
        storesleep[i] /= n;
    }
    printf(1, "\n\nPriority 1:\nAverage ready time: %d\nAverage running time: %d\nAverage sleeping time: %d\nAverage turnaround time: %d\n\n\n", storeready[0], storerun[0], storesleep[0], turnaverage[0]);
    printf(1, "Priority 2:\nAverage ready time: %d\nAverage running time: %d\nAverage sleeping time: %d\nAverage turnaround time: %d\n\n\n", storeready[1], storerun[1], storesleep[1], turnaverage[1]);
    printf(1, "Priority 3:\nAverage ready time: %d\nAverage running time: %d\nAverage sleeping time: %d\nAverage turnaround time: %d\n\n\n", storeready[2], storerun[2], storesleep[2], turnaverage[2]);
    exit();
}