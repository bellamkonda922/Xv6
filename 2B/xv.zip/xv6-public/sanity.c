#include "types.h"
#include "user.h"


int
main(int argc, char *argv[])
{
	if (argc != 2){
		printf(1, "Expected number of arguments is 2.\n");
		exit();
	}
	int n = atoi(argv[1]);
	int ctime, retime, rutime, stime;
	int calc[3][3];
	for(int i = 0; i < 3; i++) {
		for(int j = 0; j < 3; j++) {
			calc[i][j] = 0;
		}
	}
	n = atoi(argv[1]);
	int pid;
	for(int i = 0; i < 3 * n; i++) {
		int j = i % 3;
		pid = fork();
		int wasteoftime = 0;
		if(pid == 0) {//child
			j = (getpid() - 4) % 3; // ensures independence from the first son's pid when gathering the results in the second part of the program
			switch(j) {
				case 0: //CPU‐bound process (CPU):
					for(int k = 0; k < 100; k++){
						for(int j = 0; j < 1000000; j++)
                        {
							wasteoftime = ((wasteoftime + k) * j);
							wasteoftime = (wasteoftime * 8) % 1000;
                        }
					}
					break;
				case 1: //short tasks based CPU‐bound process (S‐CPU):
					for(int k = 0; k < 100; k++) {
						for(int j = 0; j < 1000000; j++) {
                            wasteoftime = wasteoftime + 1;
                            wasteoftime = (wasteoftime * 10) % 7;
                        }
						yield();
					}
					break;
				case 2:// simulate I/O bound process (IO)
					for(int k = 0; k < 100; k++){
						sleep(1);
					}
					break;
			}
			printf(1, "time waste is: %d\n", wasteoftime);
			exit(); // children exit here
		}
	}
	for(int i = 0; i < 3 * n; i++) {
		pid = wait3(&ctime, &retime, &rutime, &stime);
		int res = (pid - 4) % 3; 
		switch(res) {
			case 0: // CPU bound 
				printf(1, "CPU-bound, pid: %d, ctime: %d, ready: %d, running: %d, sleeping: %d, turnaround: %d, termination: %d\n", pid, ctime, retime, rutime, stime, retime + rutime + stime, ctime + retime + rutime + stime);
				calc[0][0] += retime;
				calc[0][1] += rutime;
				calc[0][2] += stime;
				break;
			case 1: // CPU bound  short tasks
				printf(1, "CPU-S bound, pid: %d, ctime: %d, ready: %d, running: %d, sleeping: %d, turnaround: %d, termination: %d\n", pid, ctime, retime, rutime, stime, retime + rutime + stime, ctime + retime + rutime + stime);
				calc[1][0] += retime;
				calc[1][1] += rutime;
				calc[1][2] += stime;
				break;
			case 2: // I/O bound processes
				printf(1, "I/O bound, pid: %d, ctime: %d, ready: %d, running: %d, sleeping: %d, turnaround: %d, termination: %d\n", pid, ctime, retime, rutime, stime, retime + rutime + stime, ctime + retime + rutime + stime);
				calc[2][0] += retime;
				calc[2][1] += rutime;
				calc[2][2] += stime;
				break;
		}
	}
	for(int i = 0; i < 3; i++) {
		for(int j = 0; j < 3; j++) {
			calc[i][j] /= n;
		}
	}
	printf(1, "CPU bound:\nAverage ready time: %d\nAverage running time: %d\nAverage sleeping time: %d\nAverage turnaround time: %d\n\n\n", calc[0][0], calc[0][1], calc[0][2], calc[0][0] + calc[0][1] + calc[0][2]);
	printf(1, "CPU-S bound:\nAverage ready time: %d\nAverage running time: %d\nAverage sleeping time: %d\nAverage turnaround time: %d\n\n\n", calc[1][0], calc[1][1], calc[1][2], calc[1][0] + calc[1][1] + calc[1][2]);
	printf(1, "I/O bound:\nAverage ready time: %d\nAverage running time: %d\nAverage sleeping time: %d\nAverage turnaround time: %d\n\n\n", calc[2][0], calc[2][1], calc[2][2], calc[2][0] + calc[2][1] + calc[2][2]);
	exit();
}
